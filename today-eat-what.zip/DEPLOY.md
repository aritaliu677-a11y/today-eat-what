# 今天吃什么 - 云端部署指南

## 方案一：Vercel (推荐)

### 步骤 1: 准备项目
1. 确保所有文件都在项目根目录
2. 修改 `script.js` 中的API地址为云端地址

### 步骤 2: 部署到Vercel
1. 访问 [vercel.com](https://vercel.com)
2. 用GitHub账号登录
3. 点击 "New Project"
4. 导入你的GitHub仓库
5. 点击 "Deploy"

### 步骤 3: 配置环境变量
在Vercel项目设置中添加：
- `DATABASE_URL`: 你的数据库连接字符串

## 方案二：Netlify

### 步骤 1: 准备项目
1. 创建 `netlify.toml` 配置文件
2. 修改API地址

### 步骤 2: 部署
1. 访问 [netlify.com](https://netlify.com)
2. 拖拽项目文件夹到部署区域
3. 或连接GitHub仓库自动部署

## 方案三：Heroku (全栈)

### 步骤 1: 安装Heroku CLI
```bash
# macOS
brew install heroku/brew/heroku

# 或下载安装包
# https://devcenter.heroku.com/articles/heroku-cli
```

### 步骤 2: 创建Heroku应用
```bash
heroku login
heroku create your-app-name
```

### 步骤 3: 配置数据库
```bash
heroku addons:create heroku-postgresql:hobby-dev
```

### 步骤 4: 部署
```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

## 方案四：Railway (简单)

### 步骤 1: 准备项目
1. 创建 `Procfile`:
```
web: python server.py
```

### 步骤 2: 部署
1. 访问 [railway.app](https://railway.app)
2. 连接GitHub仓库
3. 自动部署

## 注意事项

1. **数据库**: 云端部署需要云数据库，推荐：
   - PostgreSQL (Heroku, Railway)
   - MongoDB Atlas
   - PlanetScale (MySQL)

2. **环境变量**: 敏感信息通过环境变量配置

3. **CORS**: 确保API支持跨域请求

4. **HTTPS**: 所有现代平台都自动提供HTTPS
