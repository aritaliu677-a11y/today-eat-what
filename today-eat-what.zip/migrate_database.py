#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据库迁移脚本
添加rating字段，修改description字段支持数组格式
"""

import sqlite3
import json
import os
from datetime import datetime

def backup_database():
    """备份当前数据库"""
    if os.path.exists('foods.db'):
        backup_name = f'foods_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db'
        import shutil
        shutil.copy2('foods.db', backup_name)
        print(f"✅ 数据库已备份为: {backup_name}")
        return backup_name
    return None

def migrate_database():
    """迁移数据库结构"""
    conn = sqlite3.connect('foods.db')
    cursor = conn.cursor()
    
    try:
        # 检查rating字段是否已存在
        cursor.execute("PRAGMA table_info(dishes)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'rating' not in columns:
            print("📊 添加rating字段...")
            cursor.execute('ALTER TABLE dishes ADD COLUMN rating REAL DEFAULT 0.0')
            print("✅ rating字段添加成功")
        else:
            print("ℹ️  rating字段已存在")
        
        # 检查description字段是否需要更新
        cursor.execute("PRAGMA table_info(dishes)")
        columns_info = cursor.fetchall()
        description_type = None
        for col in columns_info:
            if col[1] == 'description':
                description_type = col[2]
                break
        
        if description_type == 'TEXT':
            print("📝 description字段类型已正确")
        else:
            print("ℹ️  description字段类型:", description_type)
        
        # 更新现有数据，将空的description转换为空数组
        cursor.execute("UPDATE dishes SET description = '[]' WHERE description = '' OR description IS NULL")
        updated_rows = cursor.rowcount
        print(f"🔄 更新了 {updated_rows} 条记录的description字段")
        
        conn.commit()
        print("✅ 数据库迁移完成")
        
    except Exception as e:
        print(f"❌ 数据库迁移失败: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

def verify_migration():
    """验证迁移结果"""
    conn = sqlite3.connect('foods.db')
    cursor = conn.cursor()
    
    try:
        # 检查表结构
        cursor.execute("PRAGMA table_info(dishes)")
        columns = cursor.fetchall()
        print("\n📋 当前表结构:")
        for col in columns:
            print(f"  {col[1]} - {col[2]}")
        
        # 检查数据示例
        cursor.execute("SELECT dish_name, restaurant_name, description, rating FROM dishes LIMIT 3")
        rows = cursor.fetchall()
        print("\n📊 数据示例:")
        for row in rows:
            print(f"  菜品: {row[0]}, 餐厅: {row[1]}, 描述: {row[2]}, 评分: {row[3]}")
            
    finally:
        conn.close()

if __name__ == "__main__":
    print("🔄 开始数据库迁移...")
    
    # 备份数据库
    backup_file = backup_database()
    
    try:
        # 执行迁移
        migrate_database()
        
        # 验证迁移结果
        verify_migration()
        
        print("\n🎉 数据库迁移成功完成！")
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        if backup_file:
            print(f"💾 可以从备份文件恢复: {backup_file}")
        exit(1)
