#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
直接导入CSV数据脚本
"""

import sqlite3
import json
import csv
import os

def import_csv_data():
    """导入CSV数据"""
    csv_path = "菜品数据模板_7字段.csv"
    
    if not os.path.exists(csv_path):
        print(f"❌ CSV文件不存在: {csv_path}")
        return
    
    conn = sqlite3.connect('foods.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # 读取CSV文件
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        
        if not rows:
            print("❌ CSV文件为空")
            return
        
        print(f"📊 找到 {len(rows)} 条数据")
        
        # 清空现有数据（可选）
        print("🔄 清空现有数据...")
        cursor.execute('DELETE FROM dishes')
        cursor.execute('DELETE FROM categories')
        cursor.execute('DELETE FROM restaurants')
        
        # 处理每一行数据
        imported_count = 0
        for row in rows:
            try:
                # 解析description为数组格式
                description = row.get('description', '').strip()
                if description:
                    # 如果description包含逗号，按逗号分割
                    if ',' in description:
                        description_array = [d.strip() for d in description.split(',') if d.strip()]
                    else:
                        description_array = [description]
                else:
                    description_array = []
                
                # 转换为JSON字符串存储
                description_json = json.dumps(description_array, ensure_ascii=False)
                
                # 获取或创建分类
                category_name = row.get('category_name', '').strip()
                if not category_name:
                    print(f"⚠️  跳过无分类的数据: {row.get('dish_name', 'Unknown')}")
                    continue
                
                cursor.execute('SELECT category_id FROM categories WHERE category_name = ?', (category_name,))
                category_result = cursor.fetchone()
                
                if category_result:
                    category_id = category_result['category_id']
                else:
                    # 创建新分类
                    cursor.execute('''
                        INSERT INTO categories (category_code, category_name, description) 
                        VALUES (?, ?, ?)
                    ''', (category_name.lower().replace('菜', ''), category_name, f'{category_name}分类'))
                    category_id = cursor.lastrowid
                
                # 获取或创建餐厅
                restaurant_name = row.get('restaurant_name', '').strip()
                if not restaurant_name:
                    print(f"⚠️  跳过无餐厅的数据: {row.get('dish_name', 'Unknown')}")
                    continue
                
                cursor.execute('SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?', (restaurant_name,))
                restaurant_result = cursor.fetchone()
                
                if restaurant_result:
                    restaurant_id = restaurant_result['restaurant_id']
                else:
                    # 创建新餐厅
                    restaurant_code = restaurant_name.lower().replace(' ', '_').replace('(', '').replace(')', '')
                    cursor.execute('''
                        INSERT INTO restaurants (restaurant_code, restaurant_name, description) 
                        VALUES (?, ?, ?)
                    ''', (restaurant_code, restaurant_name, f'{restaurant_name}餐厅'))
                    restaurant_id = cursor.lastrowid
                
                # 插入菜品数据
                cursor.execute('''
                    INSERT INTO dishes (dish_name, category_id, category_name, restaurant_id, restaurant_name, 
                                      type, tag, description, rating) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    row.get('dish_name', '').strip(),
                    category_id,
                    category_name,
                    restaurant_id,
                    restaurant_name,
                    row.get('type', '').strip(),
                    row.get('tag', '').strip(),
                    description_json,
                    float(row.get('rating', 0.0)) if row.get('rating', '').strip() else 0.0
                ))
                
                imported_count += 1
                print(f"✅ 导入: {row.get('dish_name', 'Unknown')} - {restaurant_name}")
                
            except Exception as e:
                print(f"⚠️  跳过错误数据: {row.get('dish_name', 'Unknown')} - {e}")
                continue
        
        conn.commit()
        print(f"\n🎉 成功导入 {imported_count} 条菜品数据")
        
        # 验证导入结果
        cursor.execute('SELECT COUNT(*) FROM dishes WHERE description != "[]" AND description != "" AND description IS NOT NULL')
        with_desc = cursor.fetchone()[0]
        cursor.execute('SELECT COUNT(*) FROM dishes')
        total = cursor.fetchone()[0]
        
        print(f"📈 导入后统计:")
        print(f"  总菜品数: {total}")
        print(f"  有描述的: {with_desc}")
        print(f"  无描述的: {total - with_desc}")
        
    except Exception as e:
        print(f"❌ 导入失败: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    print("🔄 开始导入CSV数据...")
    import_csv_data()
    print("✅ 导入完成！")
