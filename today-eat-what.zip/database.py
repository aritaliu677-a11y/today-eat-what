#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
今天吃什么 - 数据库管理脚本
用于创建和管理SQLite数据库
"""

import sqlite3
import json
import os

def create_database():
    """创建SQLite数据库和表结构"""
    # 创建数据库连接
    conn = sqlite3.connect('foods.db')
    cursor = conn.cursor()
    
    # 创建食物表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS foods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            type TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 创建分类表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            description TEXT
        )
    ''')
    
    # 插入分类数据
    categories = [
        ('dongbei', '东北菜', '东北地区特色菜系'),
        ('sichuan', '川菜', '四川菜系，以麻辣著称'),
        ('hunan', '湘菜', '湖南菜系，口味偏辣'),
        ('jiangzhe', '江浙菜', '江浙地区菜系，口味清淡'),
        ('fastfood', '快餐', '快速便捷的餐饮选择'),
        ('japanese', '日料', '日本料理'),
        ('yungui', '云贵菜', '云南贵州地区菜系'),
        ('healthy', '健康餐', '健康营养的餐饮选择')
    ]
    
    cursor.executemany('''
        INSERT OR IGNORE INTO categories (code, name, description) 
        VALUES (?, ?, ?)
    ''', categories)
    
    conn.commit()
    print("✅ 数据库和表结构创建成功！")
    return conn

def import_json_data(conn):
    """从JSON文件导入数据到数据库"""
    cursor = conn.cursor()
    
    # 读取JSON数据
    with open('data/foods.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 清空现有数据
    cursor.execute('DELETE FROM foods')
    
    # 插入食物数据
    foods = []
    for food in data['foods']:
        foods.append((
            food['name'],
            food['description'],
            food['category'],
            food['type']
        ))
    
    cursor.executemany('''
        INSERT INTO foods (name, description, category, type) 
        VALUES (?, ?, ?, ?)
    ''', foods)
    
    conn.commit()
    print(f"✅ 成功导入 {len(foods)} 条食物数据！")

def get_random_food(conn, category=None):
    """获取随机食物"""
    cursor = conn.cursor()
    
    if category and category != 'all':
        cursor.execute('''
            SELECT f.*, c.name as category_name 
            FROM foods f 
            LEFT JOIN categories c ON f.category = c.code 
            WHERE f.category = ? 
            ORDER BY RANDOM() 
            LIMIT 1
        ''', (category,))
    else:
        cursor.execute('''
            SELECT f.*, c.name as category_name 
            FROM foods f 
            LEFT JOIN categories c ON f.category = c.code 
            ORDER BY RANDOM() 
            LIMIT 1
        ''')
    
    result = cursor.fetchone()
    if result:
        return {
            'id': result[0],
            'name': result[1],
            'description': result[2],
            'category': result[3],
            'type': result[4],
            'category_name': result[6]
        }
    return None

def get_all_foods(conn):
    """获取所有食物"""
    cursor = conn.cursor()
    cursor.execute('''
        SELECT f.*, c.name as category_name 
        FROM foods f 
        LEFT JOIN categories c ON f.category = c.code 
        ORDER BY f.id
    ''')
    
    results = cursor.fetchall()
    foods = []
    for result in results:
        foods.append({
            'id': result[0],
            'name': result[1],
            'description': result[2],
            'category': result[3],
            'type': result[4],
            'category_name': result[6]
        })
    return foods

def add_food(conn, name, description, category, type_name):
    """添加新食物"""
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO foods (name, description, category, type) 
        VALUES (?, ?, ?, ?)
    ''', (name, description, category, type_name))
    conn.commit()
    print(f"✅ 成功添加食物：{name}")

def update_food(conn, food_id, name, description, category, type_name):
    """更新食物信息"""
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE foods 
        SET name = ?, description = ?, category = ?, type = ? 
        WHERE id = ?
    ''', (name, description, category, type_name, food_id))
    conn.commit()
    print(f"✅ 成功更新食物：{name}")

def delete_food(conn, food_id):
    """删除食物"""
    cursor = conn.cursor()
    cursor.execute('DELETE FROM foods WHERE id = ?', (food_id,))
    conn.commit()
    print(f"✅ 成功删除食物 ID：{food_id}")

def get_statistics(conn):
    """获取统计信息"""
    cursor = conn.cursor()
    
    # 总食物数量
    cursor.execute('SELECT COUNT(*) FROM foods')
    total_foods = cursor.fetchone()[0]
    
    # 按分类统计
    cursor.execute('''
        SELECT c.name, COUNT(f.id) as count 
        FROM categories c 
        LEFT JOIN foods f ON c.code = f.category 
        GROUP BY c.code, c.name 
        ORDER BY count DESC
    ''')
    category_stats = cursor.fetchall()
    
    print(f"📊 数据库统计信息：")
    print(f"总食物数量：{total_foods}")
    print(f"分类统计：")
    for category, count in category_stats:
        print(f"  {category}: {count} 种")

def main():
    """主函数"""
    print("🍽️ 今天吃什么 - 数据库管理工具")
    print("=" * 40)
    
    # 创建数据库
    conn = create_database()
    
    # 导入JSON数据
    if os.path.exists('data/foods.json'):
        import_json_data(conn)
        get_statistics(conn)
    else:
        print("❌ 未找到 data/foods.json 文件")
    
    conn.close()
    print("✅ 数据库操作完成！")

if __name__ == "__main__":
    main()
