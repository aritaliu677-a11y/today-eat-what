# 🚀 Heroku 部署指南

## 为什么选择Heroku？

✅ **完美支持数据库**：自动提供PostgreSQL数据库  
✅ **Python后端**：原生支持Flask应用  
✅ **免费额度**：每月550小时免费  
✅ **简单部署**：一键部署，自动配置  

## 📋 部署步骤

### 1. 安装Heroku CLI

```bash
# macOS
brew install heroku/brew/heroku

# 或访问 https://devcenter.heroku.com/articles/heroku-cli
```

### 2. 登录Heroku

```bash
heroku login
```

### 3. 创建应用

```bash
# 进入项目目录
cd /Users/arita/今天吃什么

# 创建Heroku应用
heroku create your-app-name

# 例如：
heroku create today-eat-what
```

### 4. 添加PostgreSQL数据库

```bash
# 添加免费PostgreSQL数据库
heroku addons:create heroku-postgresql:hobby-dev
```

### 5. 初始化Git仓库（如果还没有）

```bash
git init
git add .
git commit -m "Initial commit"
```

### 6. 部署到Heroku

```bash
# 添加Heroku远程仓库
heroku git:remote -a your-app-name

# 部署
git push heroku main
```

### 7. 迁移数据库

```bash
# 运行数据库迁移脚本
heroku run python migrate_to_postgres.py
```

### 8. 打开应用

```bash
heroku open
```

## 🔧 环境变量配置

Heroku会自动设置以下环境变量：
- `DATABASE_URL`: PostgreSQL连接字符串
- `PORT`: 应用端口
- `FLASK_ENV`: 生产环境

## 📊 监控和管理

```bash
# 查看应用日志
heroku logs --tail

# 查看数据库
heroku pg:psql

# 重启应用
heroku restart

# 查看应用状态
heroku ps
```

## 💰 费用说明

- **免费额度**：每月550小时
- **数据库**：PostgreSQL Hobby Dev（免费）
- **域名**：`your-app-name.herokuapp.com`
- **HTTPS**：自动提供

## 🚨 注意事项

1. **数据库迁移**：首次部署后需要运行迁移脚本
2. **静态文件**：Heroku会处理静态文件
3. **日志查看**：使用 `heroku logs` 查看错误
4. **重启应用**：修改代码后需要重新部署

## 🎯 快速部署命令

```bash
# 一键部署（在项目目录下运行）
heroku create today-eat-what
heroku addons:create heroku-postgresql:hobby-dev
git add .
git commit -m "Deploy to Heroku"
git push heroku main
heroku run python migrate_to_postgres.py
heroku open
```

## 🔍 故障排除

### 常见问题：

1. **部署失败**：检查 `requirements.txt` 和 `Procfile`
2. **数据库连接失败**：确保运行了迁移脚本
3. **静态文件404**：检查文件路径和权限
4. **端口错误**：确保使用 `os.environ.get('PORT')`

### 查看详细错误：

```bash
heroku logs --tail
```

---

🎉 **部署完成后，你的应用将在 `https://your-app-name.herokuapp.com` 运行！**
