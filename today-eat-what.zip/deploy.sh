#!/bin/bash

echo "🚀 今天吃什么 - 云端部署脚本"
echo "================================"

# 检查是否安装了必要的工具
check_tool() {
    if ! command -v $1 &> /dev/null; then
        echo "❌ 未安装 $1，请先安装"
        return 1
    else
        echo "✅ $1 已安装"
        return 0
    fi
}

# 选择部署平台
echo "请选择部署平台："
echo "1) Vercel (推荐 - 静态网站)"
echo "2) Heroku (全栈应用)"
echo "3) Railway (简单部署)"
echo "4) Netlify (静态网站)"

read -p "请输入选择 (1-4): " choice

case $choice in
    1)
        echo "📦 准备Vercel部署..."
        if check_tool "vercel"; then
            vercel --prod
        else
            echo "请先安装Vercel CLI: npm i -g vercel"
        fi
        ;;
    2)
        echo "📦 准备Heroku部署..."
        if check_tool "heroku"; then
            echo "创建Heroku应用..."
            heroku create
            echo "添加PostgreSQL数据库..."
            heroku addons:create heroku-postgresql:hobby-dev
            echo "部署到Heroku..."
            git add .
            git commit -m "Deploy to Heroku"
            git push heroku main
        else
            echo "请先安装Heroku CLI: https://devcenter.heroku.com/articles/heroku-cli"
        fi
        ;;
    3)
        echo "📦 准备Railway部署..."
        echo "请访问 https://railway.app 并连接GitHub仓库"
        echo "Railway会自动检测并部署你的应用"
        ;;
    4)
        echo "📦 准备Netlify部署..."
        if check_tool "netlify"; then
            netlify deploy --prod
        else
            echo "请先安装Netlify CLI: npm i -g netlify-cli"
        fi
        ;;
    *)
        echo "❌ 无效选择"
        exit 1
        ;;
esac

echo "🎉 部署完成！"
