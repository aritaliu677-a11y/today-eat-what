# 今天中午吃什么 - 数据库版本 🍽️

一个专为打工人设计的Web应用，使用SQLite数据库存储食物数据，提供更强大的数据管理功能。

## 🚀 快速开始

### 方法一：一键启动（推荐）
```bash
python start.py
```

### 方法二：分步启动
1. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

2. **创建数据库**
   ```bash
   python database.py
   ```

3. **启动服务器**
   ```bash
   python server.py
   ```

4. **打开前端页面**
   在浏览器中打开 `index.html`

## 📁 项目结构

```
今天吃什么/
├── index.html              # 前端页面
├── style.css               # 样式文件
├── script.js               # 前端逻辑
├── database.py             # 数据库管理脚本
├── server.py               # Web服务器
├── start.py                # 一键启动脚本
├── requirements.txt        # Python依赖
├── foods.db                # SQLite数据库文件
├── data/
│   └── foods.json          # 原始JSON数据（用于导入）
└── README_DATABASE.md      # 数据库版本说明
```

## 🗄️ 数据库结构

### foods 表（食物表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INTEGER | 主键，自增 |
| name | TEXT | 食物名称 |
| description | TEXT | 食物描述 |
| category | TEXT | 分类代码 |
| type | TEXT | 食物类型 |
| created_at | TIMESTAMP | 创建时间 |

### categories 表（分类表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | INTEGER | 主键，自增 |
| code | TEXT | 分类代码 |
| name | TEXT | 分类名称 |
| description | TEXT | 分类描述 |

## 🔧 数据库管理

### 使用 database.py 脚本

```python
# 创建数据库和表
python database.py

# 在Python中使用
from database import *

# 连接数据库
conn = get_db_connection()

# 获取随机食物
food = get_random_food(conn)

# 添加新食物
add_food(conn, "新食物", "描述", "sichuan", "主菜")

# 获取统计信息
get_statistics(conn)

conn.close()
```

## 🌐 API 接口

### 获取随机食物
```
GET /api/random-food
```

### 获取所有食物
```
GET /api/foods
```

### 根据ID获取食物
```
GET /api/foods/{id}
```

### 添加新食物
```
POST /api/foods
Content-Type: application/json

{
    "name": "食物名称",
    "description": "食物描述",
    "category": "分类代码",
    "type": "食物类型"
}
```

### 更新食物
```
PUT /api/foods/{id}
Content-Type: application/json

{
    "name": "新名称",
    "description": "新描述",
    "category": "新分类",
    "type": "新类型"
}
```

### 删除食物
```
DELETE /api/foods/{id}
```

### 获取所有分类
```
GET /api/categories
```

### 获取统计信息
```
GET /api/stats
```

## 📊 数据管理功能

### 添加新食物
```python
from database import *

conn = get_db_connection()
add_food(conn, "麻辣香锅", "四川特色，多种食材一锅炒", "sichuan", "主菜")
conn.close()
```

### 批量导入数据
```python
from database import *

conn = get_db_connection()
import_json_data(conn)  # 从JSON文件导入
conn.close()
```

### 查询统计信息
```python
from database import *

conn = get_db_connection()
get_statistics(conn)
conn.close()
```

## 🔄 数据迁移

### 从JSON迁移到数据库
1. 确保 `data/foods.json` 文件存在
2. 运行 `python database.py`
3. 数据会自动导入到SQLite数据库

### 从数据库导出到JSON
```python
from database import *
import json

conn = get_db_connection()
foods = get_all_foods(conn)
conn.close()

# 保存为JSON
with open('exported_foods.json', 'w', encoding='utf-8') as f:
    json.dump({'foods': foods}, f, ensure_ascii=False, indent=2)
```

## 🛠️ 开发说明

### 添加新分类
1. 在 `database.py` 的 `categories` 列表中添加新分类
2. 重新运行 `python database.py`

### 修改数据库结构
1. 修改 `database.py` 中的表结构
2. 删除现有的 `foods.db` 文件
3. 重新运行 `python database.py`

### 自定义API接口
在 `server.py` 中添加新的路由和功能

## 🔒 安全注意事项

- 生产环境请修改默认端口和主机
- 添加适当的身份验证和授权
- 对输入数据进行验证和清理
- 定期备份数据库文件

## 📈 性能优化

- 为常用查询字段添加索引
- 使用连接池管理数据库连接
- 实现缓存机制
- 定期清理无用数据

## 🐛 故障排除

### 数据库文件不存在
```bash
python database.py
```

### 端口被占用
修改 `server.py` 中的端口号：
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

### 跨域问题
确保 `Flask-CORS` 已正确安装和配置

---

让午餐选择变得简单，让数据管理更加便捷！ 💼🍽️
