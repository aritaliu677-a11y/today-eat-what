#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
今天吃什么 - 数据库结构更新脚本
更新为新的字段结构：dish_id, dish_name, category_id, category_name, tag
"""

import sqlite3
import json
import os
from datetime import datetime

def backup_database():
    """备份现有数据库"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"foods_backup_{timestamp}.db"
    
    if os.path.exists('foods.db'):
        import shutil
        shutil.copy2('foods.db', backup_filename)
        print(f"✅ 数据库已备份到: {backup_filename}")
        return backup_filename
    return None

def create_new_database():
    """创建新的数据库结构"""
    # 备份现有数据库
    backup_file = backup_database()
    
    # 删除现有数据库
    if os.path.exists('foods.db'):
        os.remove('foods.db')
        print("✅ 已删除旧数据库")
    
    # 创建新数据库
    conn = sqlite3.connect('foods.db')
    cursor = conn.cursor()
    
    # 创建新的分类表
    cursor.execute('''
        CREATE TABLE categories (
            category_id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_code TEXT UNIQUE NOT NULL,
            category_name TEXT NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 创建新的菜品表
    cursor.execute('''
        CREATE TABLE dishes (
            dish_id INTEGER PRIMARY KEY AUTOINCREMENT,
            dish_name TEXT NOT NULL,
            category_id INTEGER NOT NULL,
            category_name TEXT NOT NULL,
            tag TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories (category_id)
        )
    ''')
    
    # 插入分类数据
    categories = [
        ('dongbei', '东北菜', '东北地区特色菜系'),
        ('sichuan', '川菜', '四川菜系，以麻辣著称'),
        ('hunan', '湘菜', '湖南菜系，口味偏辣'),
        ('jiangzhe', '江浙菜', '江浙地区菜系，口味清淡'),
        ('fastfood', '快餐', '快速便捷的餐饮选择'),
        ('japanese', '日料', '日本料理'),
        ('yungui', '云贵菜', '云南贵州地区菜系'),
        ('healthy', '健康餐', '健康营养的餐饮选择')
    ]
    
    cursor.executemany('''
        INSERT INTO categories (category_code, category_name, description) 
        VALUES (?, ?, ?)
    ''', categories)
    
    conn.commit()
    print("✅ 新数据库结构创建成功！")
    return conn

def migrate_data(conn):
    """迁移现有数据到新结构"""
    cursor = conn.cursor()
    
    # 读取原始JSON数据
    with open('data/foods.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 创建分类映射
    category_mapping = {
        'dongbei': '东北菜',
        'sichuan': '川菜',
        'hunan': '湘菜',
        'jiangzhe': '江浙菜',
        'fastfood': '快餐',
        'japanese': '日料',
        'yungui': '云贵菜',
        'healthy': '健康餐'
    }
    
    # 获取分类ID映射
    cursor.execute('SELECT category_id, category_code FROM categories')
    category_ids = {code: cid for cid, code in cursor.fetchall()}
    
    # 迁移食物数据
    dishes = []
    for food in data['foods']:
        category_code = food['category']
        category_name = category_mapping.get(category_code, category_code)
        category_id = category_ids.get(category_code, 1)  # 默认分类ID为1
        
        # 根据食物类型生成标签
        tag = generate_tag(food['type'], food['name'])
        
        dishes.append((
            food['name'],           # dish_name
            category_id,            # category_id
            category_name,          # category_name
            tag,                    # tag
            food['description']     # description
        ))
    
    cursor.executemany('''
        INSERT INTO dishes (dish_name, category_id, category_name, tag, description) 
        VALUES (?, ?, ?, ?, ?)
    ''', dishes)
    
    conn.commit()
    print(f"✅ 成功迁移 {len(dishes)} 条菜品数据！")

def generate_tag(food_type, food_name):
    """根据食物类型和名称生成标签"""
    # 基础类型标签
    type_tags = {
        '主菜': 'main',
        '主食': 'staple',
        '甜品': 'dessert',
        '汤品': 'soup',
        '快餐': 'fast',
        '小食': 'snack',
        '点心': 'dimsum'
    }
    
    # 口味标签
    taste_keywords = {
        '麻辣': 'spicy',
        '酸甜': 'sweet_sour',
        '清淡': 'light',
        '香辣': 'fragrant_spicy',
        '酸辣': 'sour_spicy',
        '甜': 'sweet',
        '咸': 'salty',
        '鲜': 'fresh'
    }
    
    # 特色标签
    feature_keywords = {
        '炸': 'fried',
        '蒸': 'steamed',
        '炒': 'stir_fried',
        '煮': 'boiled',
        '烤': 'roasted',
        '炖': 'stewed',
        '凉': 'cold',
        '热': 'hot'
    }
    
    tags = []
    
    # 添加类型标签
    if food_type in type_tags:
        tags.append(type_tags[food_type])
    
    # 添加口味标签
    for keyword, tag in taste_keywords.items():
        if keyword in food_name:
            tags.append(tag)
            break
    
    # 添加特色标签
    for keyword, tag in feature_keywords.items():
        if keyword in food_name:
            tags.append(tag)
            break
    
    # 如果没有匹配到标签，使用默认标签
    if not tags:
        tags.append('normal')
    
    return ','.join(tags)

def show_new_structure(conn):
    """显示新数据库结构"""
    cursor = conn.cursor()
    
    print("\n📊 新数据库结构:")
    print("=" * 50)
    
    # 显示分类表结构
    cursor.execute("PRAGMA table_info(categories)")
    categories_info = cursor.fetchall()
    
    print("🏷️ categories 表:")
    for col in categories_info:
        print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
    
    # 显示菜品表结构
    cursor.execute("PRAGMA table_info(dishes)")
    dishes_info = cursor.fetchall()
    
    print("\n🍽️ dishes 表:")
    for col in dishes_info:
        print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
    
    # 显示数据统计
    cursor.execute("SELECT COUNT(*) FROM categories")
    category_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM dishes")
    dish_count = cursor.fetchone()[0]
    
    print(f"\n📈 数据统计:")
    print(f"  分类数量: {category_count}")
    print(f"  菜品数量: {dish_count}")
    
    # 显示示例数据
    cursor.execute('''
        SELECT d.dish_id, d.dish_name, d.category_name, d.tag, d.description
        FROM dishes d 
        ORDER BY d.dish_id 
        LIMIT 5
    ''')
    
    samples = cursor.fetchall()
    print(f"\n🍴 示例数据:")
    print("-" * 80)
    for sample in samples:
        print(f"ID: {sample[0]} | {sample[1]} ({sample[2]}) | 标签: {sample[3]}")
        print(f"描述: {sample[4]}")
        print("-" * 80)

def main():
    """主函数"""
    print("🔄 今天吃什么 - 数据库结构更新")
    print("=" * 50)
    print("正在更新数据库结构...")
    print("新字段: dish_id, dish_name, category_id, category_name, tag")
    print("=" * 50)
    
    try:
        # 创建新数据库
        conn = create_new_database()
        
        # 迁移数据
        migrate_data(conn)
        
        # 显示新结构
        show_new_structure(conn)
        
        conn.close()
        print("\n✅ 数据库结构更新完成！")
        
    except Exception as e:
        print(f"❌ 更新失败: {e}")
        return False
    
    return True

if __name__ == "__main__":
    main()
