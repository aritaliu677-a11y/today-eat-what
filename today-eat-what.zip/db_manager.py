#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
今天吃什么 - 数据库管理工具
交互式数据库管理界面
"""

import sqlite3
import json
import os
from datetime import datetime

class DatabaseManager:
    def __init__(self):
        self.db_path = 'foods.db'
        self.conn = None
    
    def connect(self):
        """连接数据库"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            print("✅ 数据库连接成功")
            return True
        except Exception as e:
            print(f"❌ 数据库连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开数据库连接"""
        if self.conn:
            self.conn.close()
            print("✅ 数据库连接已关闭")
    
    def show_menu(self):
        """显示主菜单"""
        print("\n" + "="*50)
        print("🍽️ 今天吃什么 - 数据库管理工具")
        print("="*50)
        print("1. 查看所有食物")
        print("2. 添加新食物")
        print("3. 修改食物信息")
        print("4. 删除食物")
        print("5. 查看分类统计")
        print("6. 搜索食物")
        print("7. 导入JSON数据")
        print("8. 导入CSV数据")
        print("9. 导出数据")
        print("10. 数据库备份")
        print("0. 退出")
        print("="*50)
    
    def show_all_foods(self):
        """显示所有菜品"""
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                SELECT d.dish_id, d.dish_name, d.category_name, d.tag, d.description
                FROM dishes d 
                ORDER BY d.dish_id
            ''')
            
            results = cursor.fetchall()
            
            if not results:
                print("📭 数据库中没有菜品数据")
                return
            
            print(f"\n📋 所有菜品列表 (共 {len(results)} 种):")
            print("-" * 90)
            print(f"{'ID':<4} {'名称':<15} {'分类':<10} {'标签':<12} {'描述'}")
            print("-" * 90)
            
            for row in results:
                desc = row['description'][:25] + "..." if len(row['description']) > 25 else row['description']
                tag = row['tag'] or '无'
                print(f"{row['dish_id']:<4} {row['dish_name']:<15} {row['category_name']:<10} {tag:<12} {desc}")
            
        except Exception as e:
            print(f"❌ 查询失败: {e}")
    
    def add_food(self):
        """添加新食物"""
        print("\n➕ 添加新食物")
        print("-" * 30)
        
        try:
            name = input("食物名称: ").strip()
            if not name:
                print("❌ 食物名称不能为空")
                return
            
            description = input("食物描述: ").strip()
            if not description:
                print("❌ 食物描述不能为空")
                return
            
            # 显示分类选项
            cursor = self.conn.cursor()
            cursor.execute('SELECT code, name FROM categories ORDER BY name')
            categories = cursor.fetchall()
            
            print("\n可选分类:")
            for i, (code, name) in enumerate(categories, 1):
                print(f"{i}. {name} ({code})")
            
            try:
                choice = int(input("选择分类 (输入序号): ")) - 1
                if 0 <= choice < len(categories):
                    category = categories[choice][0]
                else:
                    print("❌ 无效选择")
                    return
            except ValueError:
                print("❌ 请输入有效数字")
                return
            
            type_name = input("食物类型 (如: 主菜, 主食, 甜品等): ").strip()
            if not type_name:
                print("❌ 食物类型不能为空")
                return
            
            # 插入数据
            cursor.execute('''
                INSERT INTO foods (name, description, category, type) 
                VALUES (?, ?, ?, ?)
            ''', (name, description, category, type_name))
            
            self.conn.commit()
            print(f"✅ 成功添加食物: {name}")
            
        except Exception as e:
            print(f"❌ 添加失败: {e}")
    
    def update_food(self):
        """修改食物信息"""
        print("\n✏️ 修改食物信息")
        print("-" * 30)
        
        try:
            food_id = input("请输入要修改的食物ID: ").strip()
            if not food_id.isdigit():
                print("❌ 请输入有效的数字ID")
                return
            
            # 查询现有数据
            cursor = self.conn.cursor()
            cursor.execute('SELECT * FROM foods WHERE id = ?', (food_id,))
            food = cursor.fetchone()
            
            if not food:
                print("❌ 未找到该食物")
                return
            
            print(f"\n当前信息:")
            print(f"名称: {food['name']}")
            print(f"描述: {food['description']}")
            print(f"分类: {food['category']}")
            print(f"类型: {food['type']}")
            print("-" * 30)
            
            # 获取新信息
            new_name = input(f"新名称 (当前: {food['name']}): ").strip() or food['name']
            new_desc = input(f"新描述 (当前: {food['description']}): ").strip() or food['description']
            new_type = input(f"新类型 (当前: {food['type']}): ").strip() or food['type']
            
            # 显示分类选项
            cursor.execute('SELECT code, name FROM categories ORDER BY name')
            categories = cursor.fetchall()
            
            print("\n可选分类:")
            for i, (code, name) in enumerate(categories, 1):
                selected = " (当前)" if code == food['category'] else ""
                print(f"{i}. {name} ({code}){selected}")
            
            category_choice = input(f"新分类 (当前: {food['category']}, 直接回车保持): ").strip()
            if category_choice:
                try:
                    choice = int(category_choice) - 1
                    if 0 <= choice < len(categories):
                        new_category = categories[choice][0]
                    else:
                        print("❌ 无效选择，保持原分类")
                        new_category = food['category']
                except ValueError:
                    print("❌ 无效输入，保持原分类")
                    new_category = food['category']
            else:
                new_category = food['category']
            
            # 更新数据
            cursor.execute('''
                UPDATE foods 
                SET name = ?, description = ?, category = ?, type = ? 
                WHERE id = ?
            ''', (new_name, new_desc, new_category, new_type, food_id))
            
            self.conn.commit()
            print(f"✅ 成功更新食物: {new_name}")
            
        except Exception as e:
            print(f"❌ 更新失败: {e}")
    
    def delete_food(self):
        """删除食物"""
        print("\n🗑️ 删除食物")
        print("-" * 30)
        
        try:
            food_id = input("请输入要删除的食物ID: ").strip()
            if not food_id.isdigit():
                print("❌ 请输入有效的数字ID")
                return
            
            # 查询现有数据
            cursor = self.conn.cursor()
            cursor.execute('SELECT * FROM foods WHERE id = ?', (food_id,))
            food = cursor.fetchone()
            
            if not food:
                print("❌ 未找到该食物")
                return
            
            print(f"\n将要删除的食物:")
            print(f"ID: {food['id']}")
            print(f"名称: {food['name']}")
            print(f"描述: {food['description']}")
            print(f"分类: {food['category']}")
            print(f"类型: {food['type']}")
            
            confirm = input("\n确认删除? (y/N): ").strip().lower()
            if confirm == 'y':
                cursor.execute('DELETE FROM foods WHERE id = ?', (food_id,))
                self.conn.commit()
                print(f"✅ 成功删除食物: {food['name']}")
            else:
                print("❌ 取消删除")
            
        except Exception as e:
            print(f"❌ 删除失败: {e}")
    
    def show_statistics(self):
        """显示统计信息"""
        try:
            cursor = self.conn.cursor()
            
            # 总食物数量
            cursor.execute('SELECT COUNT(*) FROM foods')
            total_foods = cursor.fetchone()[0]
            
            # 按分类统计
            cursor.execute('''
                SELECT c.name, COUNT(f.id) as count 
                FROM categories c 
                LEFT JOIN foods f ON c.code = f.category 
                GROUP BY c.code, c.name 
                ORDER BY count DESC
            ''')
            category_stats = cursor.fetchall()
            
            print(f"\n📊 数据库统计信息:")
            print(f"总食物数量: {total_foods}")
            print(f"\n分类统计:")
            print("-" * 30)
            for category, count in category_stats:
                print(f"{category:<10}: {count:>3} 种")
            
        except Exception as e:
            print(f"❌ 查询统计信息失败: {e}")
    
    def search_foods(self):
        """搜索食物"""
        print("\n🔍 搜索食物")
        print("-" * 30)
        
        try:
            keyword = input("请输入搜索关键词: ").strip()
            if not keyword:
                print("❌ 搜索关键词不能为空")
                return
            
            cursor = self.conn.cursor()
            cursor.execute('''
                SELECT f.*, c.name as category_name 
                FROM foods f 
                LEFT JOIN categories c ON f.category = c.code 
                WHERE f.name LIKE ? OR f.description LIKE ?
                ORDER BY f.id
            ''', (f'%{keyword}%', f'%{keyword}%'))
            
            results = cursor.fetchall()
            
            if not results:
                print(f"📭 未找到包含 '{keyword}' 的食物")
                return
            
            print(f"\n🔍 搜索结果 (共 {len(results)} 个):")
            print("-" * 60)
            for row in results:
                print(f"ID: {row['id']} | {row['name']} ({row['category_name']})")
                print(f"描述: {row['description']}")
                print("-" * 60)
            
        except Exception as e:
            print(f"❌ 搜索失败: {e}")
    
    def import_json(self):
        """从JSON导入数据"""
        print("\n📥 从JSON导入数据")
        print("-" * 30)
        
        json_path = input("JSON文件路径 (默认: data/foods.json): ").strip() or "data/foods.json"
        
        if not os.path.exists(json_path):
            print(f"❌ 文件不存在: {json_path}")
            return
        
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            cursor = self.conn.cursor()
            
            # 清空现有数据
            cursor.execute('DELETE FROM foods')
            
            # 插入新数据
            foods = []
            for food in data['foods']:
                foods.append((
                    food['name'],
                    food['description'],
                    food['category'],
                    food['type']
                ))
            
            cursor.executemany('''
                INSERT INTO foods (name, description, category, type) 
                VALUES (?, ?, ?, ?)
            ''', foods)
            
            self.conn.commit()
            print(f"✅ 成功导入 {len(foods)} 条食物数据")
            
        except Exception as e:
            print(f"❌ 导入失败: {e}")
    
    def import_csv(self):
        """从CSV导入数据"""
        print("\n📥 从CSV导入数据")
        print("-" * 30)
        
        csv_path = input("CSV文件路径 (默认: 菜品数据模板_7字段.csv): ").strip() or "菜品数据模板_7字段.csv"
        
        if not os.path.exists(csv_path):
            print(f"❌ 文件不存在: {csv_path}")
            return
        
        try:
            import csv
            cursor = self.conn.cursor()
            
            # 读取CSV文件
            with open(csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
            
            if not rows:
                print("❌ CSV文件为空")
                return
            
            print(f"📊 找到 {len(rows)} 条数据")
            
            # 处理每一行数据
            imported_count = 0
            for row in rows:
                try:
                    # 解析description为数组格式
                    description = row.get('description', '').strip()
                    if description:
                        # 如果description包含逗号，按逗号分割
                        if ',' in description:
                            description_array = [d.strip() for d in description.split(',') if d.strip()]
                        else:
                            description_array = [description]
                    else:
                        description_array = []
                    
                    # 转换为JSON字符串存储
                    description_json = json.dumps(description_array, ensure_ascii=False)
                    
                    # 获取或创建分类
                    category_name = row.get('category_name', '').strip()
                    if not category_name:
                        print(f"⚠️  跳过无分类的数据: {row.get('dish_name', 'Unknown')}")
                        continue
                    
                    cursor.execute('SELECT category_id FROM categories WHERE category_name = ?', (category_name,))
                    category_result = cursor.fetchone()
                    
                    if category_result:
                        category_id = category_result['category_id']
                    else:
                        # 创建新分类
                        cursor.execute('''
                            INSERT INTO categories (category_code, category_name, description) 
                            VALUES (?, ?, ?)
                        ''', (category_name.lower().replace('菜', ''), category_name, f'{category_name}分类'))
                        category_id = cursor.lastrowid
                    
                    # 获取或创建餐厅
                    restaurant_name = row.get('restaurant_name', '').strip()
                    if not restaurant_name:
                        print(f"⚠️  跳过无餐厅的数据: {row.get('dish_name', 'Unknown')}")
                        continue
                    
                    cursor.execute('SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?', (restaurant_name,))
                    restaurant_result = cursor.fetchone()
                    
                    if restaurant_result:
                        restaurant_id = restaurant_result['restaurant_id']
                    else:
                        # 创建新餐厅
                        cursor.execute('''
                            INSERT INTO restaurants (restaurant_name, description) 
                            VALUES (?, ?)
                        ''', (restaurant_name, f'{restaurant_name}餐厅'))
                        restaurant_id = cursor.lastrowid
                    
                    # 插入菜品数据
                    cursor.execute('''
                        INSERT INTO dishes (dish_name, category_id, category_name, restaurant_id, restaurant_name, 
                                          type, tag, description, rating) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        row.get('dish_name', '').strip(),
                        category_id,
                        category_name,
                        restaurant_id,
                        restaurant_name,
                        row.get('type', '').strip(),
                        row.get('tag', '').strip(),
                        description_json,
                        float(row.get('rating', 0.0)) if row.get('rating', '').strip() else 0.0
                    ))
                    
                    imported_count += 1
                    
                except Exception as e:
                    print(f"⚠️  跳过错误数据: {row.get('dish_name', 'Unknown')} - {e}")
                    continue
            
            self.conn.commit()
            print(f"✅ 成功导入 {imported_count} 条菜品数据")
            
        except Exception as e:
            print(f"❌ 导入失败: {e}")
    
    def export_data(self):
        """导出数据"""
        print("\n📤 导出数据")
        print("-" * 30)
        
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                SELECT f.*, c.name as category_name 
                FROM foods f 
                LEFT JOIN categories c ON f.category = c.code 
                ORDER BY f.id
            ''')
            
            results = cursor.fetchall()
            
            # 转换为JSON格式
            foods = []
            for row in results:
                foods.append({
                    'id': row['id'],
                    'name': row['name'],
                    'description': row['description'],
                    'category': row['category'],
                    'type': row['type'],
                    'category_name': row['category_name']
                })
            
            # 保存到文件
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"exported_foods_{timestamp}.json"
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump({'foods': foods}, f, ensure_ascii=False, indent=2)
            
            print(f"✅ 数据已导出到: {filename}")
            print(f"📊 共导出 {len(foods)} 条记录")
            
        except Exception as e:
            print(f"❌ 导出失败: {e}")
    
    def backup_database(self):
        """备份数据库"""
        print("\n💾 数据库备份")
        print("-" * 30)
        
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"foods_backup_{timestamp}.db"
            
            # 复制数据库文件
            import shutil
            shutil.copy2(self.db_path, backup_filename)
            
            print(f"✅ 数据库已备份到: {backup_filename}")
            
        except Exception as e:
            print(f"❌ 备份失败: {e}")
    
    def run(self):
        """运行管理工具"""
        if not self.connect():
            return
        
        try:
            while True:
                self.show_menu()
                choice = input("\n请选择操作 (0-10): ").strip()
                
                if choice == '0':
                    print("👋 再见！")
                    break
                elif choice == '1':
                    self.show_all_foods()
                elif choice == '2':
                    self.add_food()
                elif choice == '3':
                    self.update_food()
                elif choice == '4':
                    self.delete_food()
                elif choice == '5':
                    self.show_statistics()
                elif choice == '6':
                    self.search_foods()
                elif choice == '7':
                    self.import_json()
                elif choice == '8':
                    self.import_csv()
                elif choice == '9':
                    self.export_data()
                elif choice == '10':
                    self.backup_database()
                else:
                    print("❌ 无效选择，请重新输入")
                
                input("\n按回车键继续...")
        
        finally:
            self.disconnect()

if __name__ == "__main__":
    manager = DatabaseManager()
    manager.run()
