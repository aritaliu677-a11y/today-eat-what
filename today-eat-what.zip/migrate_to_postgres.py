#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SQLite 到 PostgreSQL 迁移脚本
用于Heroku部署
"""

import sqlite3
import psycopg2
import os
import json
from urllib.parse import urlparse

def migrate_sqlite_to_postgres():
    """将SQLite数据迁移到PostgreSQL"""
    
    # 获取PostgreSQL连接信息
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        print("❌ 未找到DATABASE_URL环境变量")
        return False
    
    # 解析数据库URL
    result = urlparse(database_url)
    
    # 连接PostgreSQL
    try:
        conn_pg = psycopg2.connect(
            database=result.path[1:],
            user=result.username,
            password=result.password,
            host=result.hostname,
            port=result.port
        )
        print("✅ 成功连接到PostgreSQL")
    except Exception as e:
        print(f"❌ PostgreSQL连接失败: {e}")
        return False
    
    # 连接SQLite
    try:
        conn_sqlite = sqlite3.connect('foods.db')
        conn_sqlite.row_factory = sqlite3.Row
        print("✅ 成功连接到SQLite")
    except Exception as e:
        print(f"❌ SQLite连接失败: {e}")
        return False
    
    try:
        cursor_pg = conn_pg.cursor()
        cursor_sqlite = conn_sqlite.cursor()
        
        # 创建表结构
        print("📋 创建PostgreSQL表结构...")
        
        # 创建categories表
        cursor_pg.execute('''
            CREATE TABLE IF NOT EXISTS categories (
                category_id SERIAL PRIMARY KEY,
                category_code VARCHAR(50) UNIQUE NOT NULL,
                category_name VARCHAR(100) NOT NULL,
                description TEXT
            )
        ''')
        
        # 创建restaurants表
        cursor_pg.execute('''
            CREATE TABLE IF NOT EXISTS restaurants (
                restaurant_id SERIAL PRIMARY KEY,
                restaurant_code VARCHAR(100) UNIQUE NOT NULL,
                restaurant_name VARCHAR(200) NOT NULL,
                description TEXT
            )
        ''')
        
        # 创建dishes表
        cursor_pg.execute('''
            CREATE TABLE IF NOT EXISTS dishes (
                dish_id SERIAL PRIMARY KEY,
                dish_name VARCHAR(200) NOT NULL,
                category_id INTEGER REFERENCES categories(category_id),
                category_name VARCHAR(100),
                restaurant_id INTEGER REFERENCES restaurants(restaurant_id),
                restaurant_name VARCHAR(200),
                type VARCHAR(50),
                tag VARCHAR(100),
                description TEXT,
                rating DECIMAL(3,1) DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 迁移categories数据
        print("📦 迁移categories数据...")
        cursor_sqlite.execute('SELECT * FROM categories')
        categories = cursor_sqlite.fetchall()
        
        for cat in categories:
            cursor_pg.execute('''
                INSERT INTO categories (category_code, category_name, description)
                VALUES (%s, %s, %s)
                ON CONFLICT (category_code) DO NOTHING
            ''', (cat['category_code'], cat['category_name'], cat['description']))
        
        # 迁移restaurants数据
        print("📦 迁移restaurants数据...")
        cursor_sqlite.execute('SELECT * FROM restaurants')
        restaurants = cursor_sqlite.fetchall()
        
        for rest in restaurants:
            cursor_pg.execute('''
                INSERT INTO restaurants (restaurant_code, restaurant_name, description)
                VALUES (%s, %s, %s)
                ON CONFLICT (restaurant_code) DO NOTHING
            ''', (rest['restaurant_code'], rest['restaurant_name'], rest['description']))
        
        # 迁移dishes数据
        print("📦 迁移dishes数据...")
        cursor_sqlite.execute('SELECT * FROM dishes')
        dishes = cursor_sqlite.fetchall()
        
        for dish in dishes:
            # 获取category_id
            cursor_pg.execute('SELECT category_id FROM categories WHERE category_name = %s', (dish['category_name'],))
            category_result = cursor_pg.fetchone()
            category_id = category_result[0] if category_result else None
            
            # 获取restaurant_id
            cursor_pg.execute('SELECT restaurant_id FROM restaurants WHERE restaurant_name = %s', (dish['restaurant_name'],))
            restaurant_result = cursor_pg.fetchone()
            restaurant_id = restaurant_result[0] if restaurant_result else None
            
            cursor_pg.execute('''
                INSERT INTO dishes (dish_name, category_id, category_name, restaurant_id, 
                                  restaurant_name, type, tag, description, rating, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ''', (
                dish['dish_name'], category_id, dish['category_name'],
                restaurant_id, dish['restaurant_name'], dish['type'],
                dish['tag'], dish['description'], dish['rating'], dish['created_at']
            ))
        
        # 提交事务
        conn_pg.commit()
        print("✅ 数据迁移完成！")
        
        # 验证数据
        cursor_pg.execute('SELECT COUNT(*) FROM dishes')
        dish_count = cursor_pg.fetchone()[0]
        print(f"📊 迁移了 {dish_count} 条菜品记录")
        
        return True
        
    except Exception as e:
        print(f"❌ 迁移失败: {e}")
        conn_pg.rollback()
        return False
    finally:
        conn_pg.close()
        conn_sqlite.close()

if __name__ == '__main__':
    print("🚀 开始SQLite到PostgreSQL迁移...")
    success = migrate_sqlite_to_postgres()
    if success:
        print("🎉 迁移成功！现在可以部署到Heroku了")
    else:
        print("❌ 迁移失败，请检查错误信息")
