#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
今天吃什么 - 数据导入工具
支持从CSV、JSON等格式导入数据到数据库
"""

import sqlite3
import csv
import json
import os
from datetime import datetime

class DataImporter:
    def __init__(self, db_path='foods.db'):
        self.db_path = db_path
        self.conn = None
    
    def connect(self):
        """连接数据库"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            print("✅ 数据库连接成功")
            return True
        except Exception as e:
            print(f"❌ 数据库连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开数据库连接"""
        if self.conn:
            self.conn.close()
            print("✅ 数据库连接已关闭")
    
    def clear_all_data(self):
        """清空所有数据"""
        try:
            cursor = self.conn.cursor()
            cursor.execute('DELETE FROM dishes')
            cursor.execute('DELETE FROM categories')
            self.conn.commit()
            print("✅ 所有数据已清空")
            return True
        except Exception as e:
            print(f"❌ 清空数据失败: {e}")
            return False
    
    def import_from_csv(self, csv_file, has_header=True):
        """从CSV文件导入数据"""
        try:
            if not os.path.exists(csv_file):
                print(f"❌ CSV文件不存在: {csv_file}")
                return False
            
            cursor = self.conn.cursor()
            
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f) if has_header else csv.reader(f)
                
                if has_header:
                    # 使用字典读取器
                    for row in reader:
                        self._import_dish_row(cursor, row)
                else:
                    # 使用列表读取器，需要手动映射列
                    print("📋 请确认CSV列顺序:")
                    print("列1: dish_name (菜品名称)")
                    print("列2: category_name (分类名称)")
                    print("列3: tag (标签)")
                    print("列4: description (描述)")
                    
                    for row in reader:
                        if len(row) >= 4:
                            dish_data = {
                                'dish_name': row[0],
                                'category_name': row[1],
                                'tag': row[2],
                                'description': row[3]
                            }
                            self._import_dish_row(cursor, dish_data)
            
            self.conn.commit()
            print(f"✅ CSV数据导入成功")
            return True
            
        except Exception as e:
            print(f"❌ CSV导入失败: {e}")
            return False
    
    def import_from_json(self, json_file):
        """从JSON文件导入数据"""
        try:
            if not os.path.exists(json_file):
                print(f"❌ JSON文件不存在: {json_file}")
                return False
            
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            cursor = self.conn.cursor()
            
            # 支持多种JSON格式
            if 'dishes' in data:
                dishes = data['dishes']
            elif 'foods' in data:
                dishes = data['foods']
            elif isinstance(data, list):
                dishes = data
            else:
                print("❌ 不支持的JSON格式")
                return False
            
            for dish in dishes:
                self._import_dish_row(cursor, dish)
            
            self.conn.commit()
            print(f"✅ JSON数据导入成功，共导入 {len(dishes)} 条记录")
            return True
            
        except Exception as e:
            print(f"❌ JSON导入失败: {e}")
            return False
    
    def _import_dish_row(self, cursor, dish_data):
        """导入单条菜品数据"""
        try:
            # 获取或创建分类
            category_id = self._get_or_create_category(cursor, dish_data)
            
            # 获取或创建餐厅
            restaurant_id = self._get_or_create_restaurant(cursor, dish_data)
            
            # 插入菜品数据
            cursor.execute('''
                INSERT INTO dishes (dish_name, category_id, category_name, restaurant_id, restaurant_name, type, tag, description) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                dish_data.get('dish_name', ''),
                category_id,
                dish_data.get('category_name', ''),
                restaurant_id,
                dish_data.get('restaurant_name', '默认餐厅'),
                dish_data.get('type', '主菜'),
                dish_data.get('tag', 'normal'),
                dish_data.get('description', '')
            ))
            
        except Exception as e:
            print(f"⚠️ 导入菜品失败: {dish_data.get('dish_name', 'Unknown')} - {e}")
    
    def _get_or_create_category(self, cursor, dish_data):
        """获取或创建分类"""
        category_name = dish_data.get('category_name', '')
        category_code = dish_data.get('category_code', category_name.lower())
        
        # 查找现有分类
        cursor.execute('SELECT category_id FROM categories WHERE category_name = ?', (category_name,))
        result = cursor.fetchone()
        
        if result:
            return result['category_id']
        
        # 创建新分类
        cursor.execute('''
            INSERT INTO categories (category_code, category_name, description) 
            VALUES (?, ?, ?)
        ''', (category_code, category_name, f'{category_name}分类'))
        
        return cursor.lastrowid
    
    def _get_or_create_restaurant(self, cursor, dish_data):
        """获取或创建餐厅"""
        restaurant_name = dish_data.get('restaurant_name', '默认餐厅')
        restaurant_code = dish_data.get('restaurant_code', restaurant_name.lower().replace(' ', '_'))
        
        # 查找现有餐厅
        cursor.execute('SELECT restaurant_id FROM restaurants WHERE restaurant_name = ?', (restaurant_name,))
        result = cursor.fetchone()
        
        if result:
            return result['restaurant_id']
        
        # 创建新餐厅
        cursor.execute('''
            INSERT INTO restaurants (restaurant_code, restaurant_name, address, phone, description) 
            VALUES (?, ?, ?, ?, ?)
        ''', (restaurant_code, restaurant_name, '', '', f'{restaurant_name}餐厅'))
        
        return cursor.lastrowid
    
    def show_import_menu(self):
        """显示导入菜单"""
        print("\n" + "="*50)
        print("📥 数据导入工具")
        print("="*50)
        print("1. 从CSV文件导入")
        print("2. 从JSON文件导入")
        print("3. 清空所有数据")
        print("4. 查看当前数据")
        print("5. 手动添加数据")
        print("0. 退出")
        print("="*50)
    
    def show_current_data(self):
        """显示当前数据"""
        try:
            cursor = self.conn.cursor()
            
            # 显示统计信息
            cursor.execute('SELECT COUNT(*) FROM categories')
            category_count = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM restaurants')
            restaurant_count = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM dishes')
            dish_count = cursor.fetchone()[0]
            
            print(f"\n📊 当前数据统计:")
            print(f"分类数量: {category_count}")
            print(f"餐厅数量: {restaurant_count}")
            print(f"菜品数量: {dish_count}")
            
            if dish_count > 0:
                cursor.execute('''
                    SELECT d.dish_id, d.dish_name, d.category_name, d.restaurant_name, d.type, d.tag 
                    FROM dishes d 
                    ORDER BY d.dish_id 
                    LIMIT 10
                ''')
                
                results = cursor.fetchall()
                print(f"\n🍽️ 菜品示例 (前10条):")
                print("-" * 100)
                print(f"{'ID':<4} {'菜品名称':<15} {'分类':<10} {'餐厅':<15} {'类型':<8} {'标签'}")
                print("-" * 100)
                for row in results:
                    print(f"{row['dish_id']:<4} {row['dish_name']:<15} {row['category_name']:<10} {row['restaurant_name']:<15} {row['type']:<8} {row['tag'] or '无'}")
            
        except Exception as e:
            print(f"❌ 查询失败: {e}")
    
    def manual_add_data(self):
        """手动添加数据"""
        print("\n➕ 手动添加菜品")
        print("-" * 30)
        
        try:
            dish_name = input("菜品名称: ").strip()
            if not dish_name:
                print("❌ 菜品名称不能为空")
                return
            
            category_name = input("分类名称: ").strip()
            if not category_name:
                print("❌ 分类名称不能为空")
                return
            
            restaurant_name = input("餐厅名称 (默认: 默认餐厅): ").strip() or "默认餐厅"
            type_name = input("菜品类型 (默认: 主菜): ").strip() or "主菜"
            tag = input("标签 (可选): ").strip() or "normal"
            description = input("描述: ").strip()
            
            cursor = self.conn.cursor()
            category_id = self._get_or_create_category(cursor, {
                'category_name': category_name,
                'category_code': category_name.lower()
            })
            
            restaurant_id = self._get_or_create_restaurant(cursor, {
                'restaurant_name': restaurant_name,
                'restaurant_code': restaurant_name.lower().replace(' ', '_')
            })
            
            cursor.execute('''
                INSERT INTO dishes (dish_name, category_id, category_name, restaurant_id, restaurant_name, type, tag, description) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (dish_name, category_id, category_name, restaurant_id, restaurant_name, type_name, tag, description))
            
            self.conn.commit()
            print(f"✅ 成功添加菜品: {dish_name}")
            
        except Exception as e:
            print(f"❌ 添加失败: {e}")
    
    def run(self):
        """运行导入工具"""
        if not self.connect():
            return
        
        try:
            while True:
                self.show_import_menu()
                choice = input("\n请选择操作 (0-5): ").strip()
                
                if choice == '0':
                    print("👋 再见！")
                    break
                elif choice == '1':
                    csv_file = input("CSV文件路径: ").strip()
                    has_header = input("是否有表头? (y/N): ").strip().lower() == 'y'
                    self.import_from_csv(csv_file, has_header)
                elif choice == '2':
                    json_file = input("JSON文件路径: ").strip()
                    self.import_from_json(json_file)
                elif choice == '3':
                    confirm = input("确认清空所有数据? (y/N): ").strip().lower()
                    if confirm == 'y':
                        self.clear_all_data()
                elif choice == '4':
                    self.show_current_data()
                elif choice == '5':
                    self.manual_add_data()
                else:
                    print("❌ 无效选择，请重新输入")
                
                input("\n按回车键继续...")
        
        finally:
            self.disconnect()

if __name__ == "__main__":
    importer = DataImporter()
    importer.run()
