#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
今天吃什么 - 数据库结构更新脚本 V2
更新为新的字段结构：dish_id, dish_name, category_id, category_name, restaurant_id, restaurant_name, type, tag
"""

import sqlite3
import json
import os
from datetime import datetime

def backup_database():
    """备份现有数据库"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"foods_backup_v2_{timestamp}.db"
    
    if os.path.exists('foods.db'):
        import shutil
        shutil.copy2('foods.db', backup_filename)
        print(f"✅ 数据库已备份到: {backup_filename}")
        return backup_filename
    return None

def create_new_database():
    """创建新的数据库结构"""
    # 备份现有数据库
    backup_file = backup_database()
    
    # 删除现有数据库
    if os.path.exists('foods.db'):
        os.remove('foods.db')
        print("✅ 已删除旧数据库")
    
    # 创建新数据库
    conn = sqlite3.connect('foods.db')
    cursor = conn.cursor()
    
    # 创建分类表
    cursor.execute('''
        CREATE TABLE categories (
            category_id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_code TEXT UNIQUE NOT NULL,
            category_name TEXT NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 创建餐厅表
    cursor.execute('''
        CREATE TABLE restaurants (
            restaurant_id INTEGER PRIMARY KEY AUTOINCREMENT,
            restaurant_code TEXT UNIQUE NOT NULL,
            restaurant_name TEXT NOT NULL,
            address TEXT,
            phone TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 创建菜品表
    cursor.execute('''
        CREATE TABLE dishes (
            dish_id INTEGER PRIMARY KEY AUTOINCREMENT,
            dish_name TEXT NOT NULL,
            category_id INTEGER NOT NULL,
            category_name TEXT NOT NULL,
            restaurant_id INTEGER NOT NULL,
            restaurant_name TEXT NOT NULL,
            type TEXT NOT NULL,
            tag TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories (category_id),
            FOREIGN KEY (restaurant_id) REFERENCES restaurants (restaurant_id)
        )
    ''')
    
    # 插入默认分类数据
    categories = [
        ('dongbei', '东北菜', '东北地区特色菜系'),
        ('sichuan', '川菜', '四川菜系，以麻辣著称'),
        ('hunan', '湘菜', '湖南菜系，口味偏辣'),
        ('jiangzhe', '江浙菜', '江浙地区菜系，口味清淡'),
        ('fastfood', '快餐', '快速便捷的餐饮选择'),
        ('japanese', '日料', '日本料理'),
        ('yungui', '云贵菜', '云南贵州地区菜系'),
        ('healthy', '健康餐', '健康营养的餐饮选择'),
        ('xijiang', '新疆菜', '新疆地区特色菜系'),
        ('xican', '西餐', '西方料理'),
        ('zhongshi', '中式快餐', '中式快速餐饮')
    ]
    
    cursor.executemany('''
        INSERT INTO categories (category_code, category_name, description) 
        VALUES (?, ?, ?)
    ''', categories)
    
    # 插入默认餐厅数据
    restaurants = [
        ('default', '默认餐厅', '系统默认餐厅', '', '', '默认餐厅，用于未指定餐厅的菜品'),
        ('kfc', '肯德基', '肯德基快餐店', '全国连锁', '400-882-3823', '美式快餐连锁品牌'),
        ('mcdonalds', '麦当劳', '麦当劳快餐店', '全国连锁', '400-851-7517', '美式快餐连锁品牌'),
        ('subway', '赛百味', '赛百味三明治店', '全国连锁', '400-820-3823', '美式三明治连锁品牌'),
        ('pizza_hut', '必胜客', '必胜客披萨店', '全国连锁', '400-820-3823', '美式披萨连锁品牌'),
        ('starbucks', '星巴克', '星巴克咖啡店', '全国连锁', '400-820-3823', '美式咖啡连锁品牌'),
        ('local_1', '本地餐厅1', '本地特色餐厅', '市中心', '138-0000-0000', '本地特色餐厅'),
        ('local_2', '本地餐厅2', '本地特色餐厅', '商业区', '138-0000-0001', '本地特色餐厅')
    ]
    
    cursor.executemany('''
        INSERT INTO restaurants (restaurant_code, restaurant_name, address, phone, description) 
        VALUES (?, ?, ?, ?, ?)
    ''', restaurants)
    
    conn.commit()
    print("✅ 新数据库结构创建成功！")
    return conn

def migrate_existing_data(conn):
    """迁移现有数据到新结构"""
    cursor = conn.cursor()
    
    # 获取现有数据
    cursor.execute('SELECT * FROM dishes')
    existing_dishes = cursor.fetchall()
    
    if not existing_dishes:
        print("📭 没有现有数据需要迁移")
        return
    
    print(f"📦 发现 {len(existing_dishes)} 条现有数据，开始迁移...")
    
    # 清空现有dishes表
    cursor.execute('DELETE FROM dishes')
    
    # 重新插入数据，添加默认餐厅信息
    for dish in existing_dishes:
        # 获取默认餐厅ID
        cursor.execute('SELECT restaurant_id FROM restaurants WHERE restaurant_code = ?', ('default',))
        restaurant_id = cursor.fetchone()[0]
        
        # 生成type字段（从tag推断）
        tag = dish[4] if len(dish) > 4 else 'normal'
        type_name = generate_type_from_tag(tag)
        
        cursor.execute('''
            INSERT INTO dishes (dish_name, category_id, category_name, restaurant_id, restaurant_name, type, tag, description) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            dish[1],  # dish_name
            dish[2],  # category_id
            dish[3],  # category_name
            restaurant_id,  # restaurant_id
            '默认餐厅',  # restaurant_name
            type_name,  # type
            tag,  # tag
            dish[5] if len(dish) > 5 else ''  # description
        ))
    
    conn.commit()
    print(f"✅ 成功迁移 {len(existing_dishes)} 条菜品数据！")

def generate_type_from_tag(tag):
    """根据标签生成类型"""
    if not tag:
        return '主菜'
    
    type_mapping = {
        'main': '主菜',
        'staple': '主食',
        'dessert': '甜品',
        'soup': '汤品',
        'fast': '快餐',
        'snack': '小食',
        'dimsum': '点心',
        'drink': '饮品',
        'salad': '沙拉'
    }
    
    # 检查标签中是否包含类型关键词
    for key, value in type_mapping.items():
        if key in tag.lower():
            return value
    
    return '主菜'  # 默认类型

def show_new_structure(conn):
    """显示新数据库结构"""
    cursor = conn.cursor()
    
    print("\n📊 新数据库结构 V2:")
    print("=" * 60)
    
    # 显示分类表结构
    cursor.execute("PRAGMA table_info(categories)")
    categories_info = cursor.fetchall()
    
    print("🏷️ categories 表:")
    for col in categories_info:
        print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
    
    # 显示餐厅表结构
    cursor.execute("PRAGMA table_info(restaurants)")
    restaurants_info = cursor.fetchall()
    
    print("\n🏪 restaurants 表:")
    for col in restaurants_info:
        print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
    
    # 显示菜品表结构
    cursor.execute("PRAGMA table_info(dishes)")
    dishes_info = cursor.fetchall()
    
    print("\n🍽️ dishes 表:")
    for col in dishes_info:
        print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
    
    # 显示数据统计
    cursor.execute("SELECT COUNT(*) FROM categories")
    category_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM restaurants")
    restaurant_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM dishes")
    dish_count = cursor.fetchone()[0]
    
    print(f"\n📈 数据统计:")
    print(f"  分类数量: {category_count}")
    print(f"  餐厅数量: {restaurant_count}")
    print(f"  菜品数量: {dish_count}")
    
    # 显示示例数据
    cursor.execute('''
        SELECT d.dish_id, d.dish_name, d.category_name, d.restaurant_name, d.type, d.tag
        FROM dishes d 
        ORDER BY d.dish_id 
        LIMIT 5
    ''')
    
    samples = cursor.fetchall()
    print(f"\n🍴 示例数据:")
    print("-" * 100)
    for sample in samples:
        print(f"ID: {sample[0]} | {sample[1]} | {sample[2]} | {sample[3]} | {sample[4]} | 标签: {sample[5]}")
    print("-" * 100)

def main():
    """主函数"""
    print("🔄 今天吃什么 - 数据库结构更新 V2")
    print("=" * 60)
    print("正在更新数据库结构...")
    print("新字段: dish_id, dish_name, category_id, category_name, restaurant_id, restaurant_name, type, tag")
    print("=" * 60)
    
    try:
        # 创建新数据库
        conn = create_new_database()
        
        # 迁移现有数据
        migrate_existing_data(conn)
        
        # 显示新结构
        show_new_structure(conn)
        
        conn.close()
        print("\n✅ 数据库结构更新完成！")
        
    except Exception as e:
        print(f"❌ 更新失败: {e}")
        return False
    
    return True

if __name__ == "__main__":
    main()
