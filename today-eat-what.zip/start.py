#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
今天吃什么 - 启动脚本
自动创建数据库并启动Web服务器
"""

import subprocess
import sys
import os
import time

def check_python_packages():
    """检查Python包是否安装"""
    try:
        import flask
        import flask_cors
        print("✅ Python依赖包检查通过")
        return True
    except ImportError as e:
        print(f"❌ 缺少Python包: {e}")
        print("请运行: pip install -r requirements.txt")
        return False

def create_database():
    """创建数据库"""
    print("📊 正在创建数据库...")
    try:
        result = subprocess.run([sys.executable, 'database.py'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ 数据库创建成功")
            return True
        else:
            print(f"❌ 数据库创建失败: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ 数据库创建异常: {e}")
        return False

def start_server():
    """启动Web服务器"""
    print("🚀 正在启动Web服务器...")
    try:
        subprocess.run([sys.executable, 'server.py'])
    except KeyboardInterrupt:
        print("\n👋 服务器已停止")
    except Exception as e:
        print(f"❌ 服务器启动失败: {e}")

def main():
    """主函数"""
    print("🍽️ 今天吃什么 - 启动脚本")
    print("=" * 40)
    
    # 检查Python包
    if not check_python_packages():
        return
    
    # 创建数据库
    if not create_database():
        return
    
    print("\n🎉 所有准备工作完成！")
    print("📡 Web服务器将在 http://localhost:5000 启动")
    print("🌐 前端页面请打开 index.html")
    print("⏹️  按 Ctrl+C 停止服务器")
    print("=" * 40)
    
    # 启动服务器
    start_server()

if __name__ == "__main__":
    main()
